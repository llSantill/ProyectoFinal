# Proyecto Final Telemática

Proyecto con frontend, Prometheus, Grafana, Node Exporter y cAdvisor.

## Ejecutar

```bash
docker-compose up -d --build
```

## URLs

- Frontend: http://localhost:8080
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3001
- cAdvisor: http://localhost:8081
- Node Exporter: http://localhost:9100

## Acceso a Grafana

- Usuario: `admin`
- Contraseña: `12345678`

Grafana carga automáticamente el datasource de Prometheus y los dashboards guardados en `grafana/dashboards`.

## Detener

```bash
docker-compose down
```

No usar `docker-compose down -v` si quieres conservar el volumen local de Grafana.
