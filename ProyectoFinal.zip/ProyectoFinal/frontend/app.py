
import random
import time
from datetime import datetime

from flask import Flask, Response, render_template, request
from prometheus_client import Counter, Gauge, Histogram, generate_latest

app = Flask(__name__)

PAGE_VISITS = Counter(
    "mundial_page_visits_total",
    "Total de visitas a la plataforma del mundial",
    ["path", "method", "status"],
)

PLAYER_CLICKS = Counter(
    "mundial_player_clicks_total",
    "Clicks realizados sobre jugadores destacados",
    ["player"],
)

REQUEST_LATENCY = Histogram(
    "mundial_request_latency_seconds",
    "Tiempo de respuesta de la aplicacion",
    ["path"],
)

ACTIVE_USERS = Gauge(
    "mundial_active_users",
    "Usuarios activos estimados"
)

PLAYERS = [
    {
        "name": "Lionel Messi",
        "team": "Argentina",
        "position": "Delantero",
        "description": "Capitan y referente historico."
    },
    {
        "name": "Kylian Mbappe",
        "team": "Francia",
        "position": "Delantero",
        "description": "Velocidad y definicion explosiva."
    },
    {
        "name": "Jude Bellingham",
        "team": "Inglaterra",
        "position": "Mediocampista",
        "description": "Control y vision de juego."
    }
]

@app.before_request
def before_request():
    request.start_time = time.time()

@app.after_request
def after_request(response):
    elapsed = time.time() - request.start_time
    REQUEST_LATENCY.labels(path=request.path).observe(elapsed)

    PAGE_VISITS.labels(
        path=request.path,
        method=request.method,
        status=response.status_code
    ).inc()

    ACTIVE_USERS.set(random.randint(15, 90))

    return response

@app.route("/")
def index():
    return render_template(
        "index.html",
        players=PLAYERS,
        generated=datetime.now().strftime("%H:%M:%S")
    )

@app.route("/player/<name>")
def player(name):
    PLAYER_CLICKS.labels(player=name).inc()
    return {"status": "ok", "player": name}

@app.route("/metrics")
def metrics():
    return Response(generate_latest(), mimetype="text/plain")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
